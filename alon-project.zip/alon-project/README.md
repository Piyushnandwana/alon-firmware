# Alon — desk-pet firmware (Waveshare ESP32-S3-Touch-AMOLED-1.75C)

A rebuilt, responsive version of the Alon LEGO desk pet. It fixes the two
problems in the old build: **swipes/scrolling didn't work** and **touch felt
slow**.

## What was actually wrong (and what changed)

1. **Wrong touch-reset pin.** The old notes reset touch on **GPIO2** — but on
   this board GPIO2 is the SD-card clock. The real touch reset is **GPIO40**.
   This build uses the correct pin and the exact init from Waveshare's own
   CST9217 example. *(This is the main fix.)*
2. **Swipes now fire mid-drag** (after ~60 px), not when you lift your finger.
3. **Buttons act the instant you touch them** (on finger-down), so it feels snappy.
4. **Only the parts of the screen that change are repainted** — no slow
   full-screen redraws on every touch.
5. Touch is **interrupt-driven** with a short safety poll, as the chip requires.

It also fixes two spec mistakes: this board has **16 MB** flash (not 32 MB) and
no GPIO backlight (brightness is a panel command). Settings here match the board.

## How to get a flashable .bin (no software to install)

You can't hand-write a `.bin` — code has to be *compiled* first. This repo
compiles itself in the cloud with GitHub Actions and hands you the `.bin`.

1. Put these files in a GitHub repository (keep the folder layout:
   `Alon/Alon.ino`, `.github/workflows/build.yml`, `README.md`).
2. GitHub runs the build automatically. Open the **Actions** tab → the latest
   run → wait for the green check (~2–4 min).
3. Download **`Alon-firmware`** from that run's **Artifacts**. Inside is
   `Alon-flash-at-0x0.bin`.
   - Tip: push a tag like `v1` and the `.bin` is also attached under
     **Releases**, which is an easier, stable download link.

## How to flash it (same tool you already use)

1. Open <https://adafruit.github.io/Adafruit_WebSerial_ESPTool/> in Chrome/Edge.
2. Plug the board into the **USB** port (not UART). Click **Connect**, pick the
   COM port.
3. Set the offset to **`0x0`**, choose `Alon-flash-at-0x0.bin`, click **Program**.
4. If it refuses: hold **BOOT**, tap **RST**, release BOOT, then Program again.

## Using Alon

- **Tap the face** to pet him (fun up).
- **CARE / PLAY / SHOP / Zzz** buttons on the home screen.
- **Swipe up** → games (Snake, Whack-a-mole, 2048). **Swipe left** → all stats.
- **Hold the face** → Agent mode (animated aura + level bar).
- **Shake** the device → wake him / small surprise.
- Snake & 2048 are swipe-controlled; Whack-a-mole is tap. Games pay out studs.
- Everything is offline. Progress is saved to the board's flash (NVS).

## If something's off after flashing

- **Taps land in the wrong spot** → in `Alon/Alon.ino`, flip
  `TOUCH_FLIP_X` / `TOUCH_FLIP_Y` / `TOUCH_SWAP_XY` (set to 1), re-run the build.
- **Build fails** → open the failed Actions step and send me the red error text;
  the libraries occasionally rename a version. I'll pin it.

## Not yet included (easy Phase 2 adds)

- **Sound** (ES8311 beeps) — needs the codec enabled via the TCA9554 expander; left
  out so the first build is rock-solid. Hook into `beep()`.
- **Battery %** (AXP2101) and **real voice capture** (ES7210) for Agent mode.
- **Your real LEGO artwork** — the face is drawn in code now; it can be swapped
  for your 466×466 images.
